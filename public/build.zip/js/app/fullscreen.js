function toggleFullScreen() {return document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();}
